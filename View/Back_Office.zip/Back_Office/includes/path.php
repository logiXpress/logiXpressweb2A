<?php
$current_page = basename($_SERVER['PHP_SELF']);
?>

